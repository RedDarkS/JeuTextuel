#include "Punch.h"

//Constructeurs
Punch::Punch():degats(10),name("defaut")
{}
Punch::Punch(int d, string n, string e, string t) : degats(d), name(n), effet(e), type(t)
{}
// Punch::~Punch()
// {
//   cout<<getName()<<" punché"<<endl;
// }

//Getters
int Punch::getDegats()const
{
  return degats;
}
string Punch::getEffect()const
{
  return effet;
}
string Punch::getType()const
{
  return type;
}
string Punch::getName()const
{
  return name;
}
bool Punch::getUse()const
{
  return use;
}

//Setters
void Punch::setDegats(int d)
{
  degats = d;
}
void Punch::setName(int n)
{
  name = n;
}
void Punch::setEffect(string e)
{
  effet = e;
}
void Punch::setType(string t)
{
  type = t;
}
void Punch::setUse(bool u)
{
  use = u;
}

//Méthodes
void Punch::effect(Personnage &lanceur, Personnage &cible, Public &p)
{
  // cout<<"Punch simple"<<endl;
  // cout << "Faiblesse : "<< cible.getFaiblesse() << " / Type : " << getType() << endl;

  if(cible.getFaiblesse() == getType())
  {
    cout<<"Ouch ça fait très mal !"<<endl;
    cible.setHonte(cible.getHonte() + 2*(getDegats()) );
  }
  else if(cible.getResistance() == getType())
  {
    cout<<"ça ne semble pas avoir fait mal."<<endl;
    cible.setHonte(cible.getHonte() + 2/(getDegats()) );
  }
  else
  {
    cout<<"Ouch !"<<endl;
    cible.setHonte(cible.getHonte() + getDegats());
  }
}
ostream& operator<<(ostream& os, Punch const &p)
{
  os<<"----"<<p.getName()<<"----"<<endl;
  if(p.getDegats() == 20)
  {
    os<<"----Punch lourde----"<<endl;
    os<<"Degats public = 10"<<endl;
  }
  else if(p.getDegats() == 5)
  {
    os<<"----Punch légère----"<<endl;
    os<<"Degats public = 10"<<endl;
  }
  else
  {
    os<<"----Punch normal----"<<endl;
  }
  os<<"Degats = "<<p.getDegats()<<endl;
  os<<"Type = "<<p.getType()<<endl<<endl;
  // os<<"Effets = "<<p.getEffect()<<endl<<endl;
  return os;
}
