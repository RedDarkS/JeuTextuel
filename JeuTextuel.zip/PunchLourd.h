#ifndef PUNCHLOURD_H
#define PUNCHLOURD_H

#include <iostream>
#include <string>
#include "Punch.h"

using namespace std;

class PunchLourd : public Punch
{
  private:

    int degatLourd = 10;

  public:

    //CONSTRUCTEURS
    PunchLourd();
    PunchLourd(int d, string n, string e, string t, int dp);
    // ~PunchLourd();

    //GETTERS
    int getDegatLourd() const;

    //SETTERS
    void setDegatLourd(int dp);

    //METHODES
    void attackPublic(Personnage &lanceur, Personnage &cible, Public &p);
    virtual void effect(Personnage &lanceur, Personnage &cible, Public &p);
    friend ostream& operator<<(ostream& os,PunchLourd const &p);
};

#endif // PUNCHLOURD_H