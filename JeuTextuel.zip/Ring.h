#ifndef RING_H
#define RING_H

#include <iostream>
#include <string>
#include <vector>

#include "Personnage.h"

class Personnage;

using namespace std;

class Ring
{
  private:
    string name;
    vector<Personnage*> ring;

  public:
    //constructeurs
    Ring(string n, Personnage &j, Personnage &e);
    // ~Ring();

    //Getter
    string getName()const;
    vector<Personnage*> getRing() const;

    //Setter
    void setName(string n);
    void setRing(vector<Personnage*> r);

    //METHODES
    void changement(Personnage &p, string e);
    Personnage* actif(string a);
};

#endif