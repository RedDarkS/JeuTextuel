#ifndef PUNCH_H
#define PUNCH_H

#include <iostream>
#include <string>
#include <vector>
#include "Public.h"
#include "Personnage.h"

class Personnage;

using namespace std;

class Punch
{
  private:
    string name;
    int degats = 10;
    string effet;
    string type;
    bool use = false;
    
  public:

    //constructeurs
    Punch();
    Punch(int deg, string nom, string effet, string typ);
    // ~Punch();

    //Getter
    int getDegats()const;
    string getName()const;
    string getEffect()const;
    string getType()const;
    bool getUse()const;

    //Setter
    void setUse(bool u);
    void setEffect(string e);
    void setDegats(int d);
    void setName(int n);
    void setType(string t);

    //Méthode
    virtual void effect(Personnage &lanceur, Personnage &cible, Public &p);
    friend ostream& operator<<(ostream& os,Punch const &p);
};
#endif // PUNCH_H