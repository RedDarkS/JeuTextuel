#ifndef PERSONNAGE_H
#define PERSONNAGE_H

#include <iostream>
#include <string>
#include <vector>
#include "Punch.h"
#include "Public.h"

class Punch;
class Public;

using namespace std;

class Personnage
{
  private:
    string name;
    int honte = 0;
    vector<Punch*> punchs;
    string faiblesse;
    string resistance;
    string type;

  public:
    //CONSTRUCTEURS / DESTRUCTEURS
    Personnage();
    Personnage(string n, string f, string r, string typ);
    // ~Personnage();

    //GETTERS
    string getName()const;
    int getHonte()const;
    string getFaiblesse() const;
    string getResistance() const;
    string getType() const;
    vector<Punch*> getPunchs() const;
    Punch* getElemPunchs(vector<Punch*> p, int index) const;

    //SETTERS
    void setName(string n);
    void setHonte(int h);
    void setFaiblesse(string f);
    void setResistance(string r);
    void setType(string t);
    void setPunchs(vector<Punch*> p);

    //METHODES
    void learnPunch(Punch &p);
    void punchEnemy(Personnage &lanceur, Personnage &cible, Punch &p, Public &pb);
    friend ostream& operator<<(ostream &os,Personnage const &p);
};

#endif // PERSONNAGE_H