#include "Ring.h"

Ring::Ring(string n, Personnage &j, Personnage &e)
{
  name = n;
  ring.push_back(&j);
  ring.push_back(&e);
}
// Ring::~Ring()
// {
//   cout<<getName()<<" a explosé."<<endl;
// }

//Getter
string Ring::getName()const
{
  return name;
}
vector<Personnage*> Ring::getRing() const
{
  return ring;
}

//Setter
void Ring::setName(string n)
{
  name = n;
}
void Ring::setRing(vector<Personnage*> r)
{
  ring = r;
}

//METHODES
void Ring::changement(Personnage &p, string e)
{
  if(e == "joueur")
  {
    ring[0] = &p;
  }
  else if(e == "ennemi")
  {
    ring[1] = &p;
  }
}

Personnage* Ring::actif(string a)
{
  if(a == "joueur")
  {
    return ring[0];
  }
  else if(a == "ennemi")
  {
    return ring[1];
  }
  return ring[0];
}