#ifndef PUBLIC_H
#define PUBLIC_H

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Public
{
  private:
    string name;
    int interest = 50;

  public:
    //constructeurs
    Public(string n);
    // ~Public();

    //Getter
    int getInterest()const;

    //Setter
    void setInterest(int i);

    //METHODES
    friend ostream& operator<<(ostream& os,Public const & p);
};

#endif // PUBLIC_H