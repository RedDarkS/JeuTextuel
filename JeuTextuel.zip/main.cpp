#include "Personnage.h"
#include "Punch.h"
#include "PunchLeger.h"
#include "PunchLourd.h"
#include "Public.h"
#include "Ring.h"

#include <iostream>
#include <string>
#include <vector>
#include "cmath"

using namespace std;

int main()
{
  int skip = 0;
  srand(time(NULL));


  //PERSONNAGES JOUABLES


  //MK
  Personnage Mk("MK", "Travail", "Famille", "Joueur");

  PunchLourd punchLD1(10,"Ta mère voulait un voyage pour Noël mais c'était toi sous le tapin.", "Normal", "Famille", 10);
  Mk.learnPunch(punchLD1);

  PunchLourd punchLD8(10,"Vas y je t'atteeeends.", "Normal", "Physique", 10);
  Mk.learnPunch(punchLD8);

  PunchLeger punchLG0(10, "Un glandu sauvage apparait...", "Normal", "Travail", 10);
  Mk.learnPunch(punchLG0);

  Punch punch2(10, "Mais du coup pour le game concept, on fait quoi ?",  "Normal",  "Travail");
  Mk.learnPunch(punch2);


  //Lil Women
  Personnage LW("Lil Women", "Physique", "Famille", "Joueur");

  PunchLourd punchLD0(10,"Le meilleur moyen de contraception c'est de penser à toi.", "Normal","Famille", 10);
  LW.learnPunch(punchLD0);

  Punch punch0(10, "Ta famille doit avoir honte.",  "Normal",  "Famille");
  LW.learnPunch(punch0);

  Punch punch6(10,  "Et l'organisation ça vous dirait de vous pencher dessus ?",  "Normal",  "Travail");
  LW.learnPunch(punch6);

  PunchLeger punchLG4(10, "Et vous ? Un cutter ça vous parle ?", "Normal", "Travail", 10);
  LW.learnPunch(punchLG4);


  //Bri-Bri
  Personnage BB("Bri-Bri", "Travail", "Famille", "Joueur");

  PunchLourd punchLD11(10,"Le cahier des charges c'est comme l'école, à la fin de l'année il sera toujours pas fini.", "Normal", "Travail", 10);
  BB.learnPunch(punchLD11);

  PunchLeger punchLG2(10, "Mais vous fumez Monsieur !", "Normal", "Travail", 10);
  BB.learnPunch(punchLG2);

  Punch punch7(10,  "Alors on dessine que sur Ipad ?",  "Normal",  "Travail");
  BB.learnPunch(punch7);

  Punch punchPoids(10, "Vous avez penser a perdre du poids ?", "Normal", "Physique");
  BB.learnPunch(punchPoids);
  

  //Hitch Hitch
  Personnage HH("Hitch Hitch", "Physique", "Travail", "Joueur");

  PunchLourd punchLD3(10,"Fils de p***.", "Normal", "Famille", 10);
  HH.learnPunch(punchLD3);

  PunchLourd punchLD10(10,  "T'as vu ta gueule on dirait un lépreu.",  "Normal",  "Physique", 10);
  HH.learnPunch(punchLD10);

  PunchLeger punchLG1(10, "Vous voyez,  c'est là qu'on récolte tout le sel français. Et il est bon !", "Normal", "Travail", 10);
  HH.learnPunch(punchLG1);

  Punch punch4(10, "Alors ? Apparement on peut pas bosser si on a pas eu son café ?",  "Normal",  "Travail");
  HH.learnPunch(punch4);
  

  //Ordure Spaciale
  Personnage OS("Ordure Spatiale", "Travail", "Famille", "Joueur");

  PunchLourd punchLD2(10,"Ta mère est tellement grosse qu'il y a un décalage horaire entre ses deux fesses.", "Normal", "Famille", 10);
  OS.learnPunch(punchLD2);

  PunchLourd punchLD9(10,"Si je devais demander à passer sous un bureau ce serait pas le tien !", "Normal", "Physique", 10);
  OS.learnPunch(punchLD9);

  Punch punch1(10, "C'est pour votre travail que tout le monde vous déteste.",  "Normal",  "Travail");
  OS.learnPunch(punch1);

  Punch punch10(10,  "Silence, ton nom est puanteur.",  "Normal",  "Physique");
  OS.learnPunch(punch10);


  //120 Ceents
	Personnage CVC("120 Ceents", "Famille", "Physique", "Joueur");

  PunchLourd punchLD7(10,"T'as pas besoin d'une colo avec autant de cheveux blancs ?", "Normal", "Physique", 10);
  CVC.learnPunch(punchLD7);

  PunchLeger punchLG3(10, "Tu sais que dans 3 ans je gagnerai 3 fois plus ?!", "Normal", "Travail", 10);
  CVC.learnPunch(punchLG3);

  Punch punch3(10, "Nan mais tu veux quoi toi ? Je t'ai vu corriger hier soir ! Va pas faire croire tu taff.",  "Normal",  "Travail");
  CVC.learnPunch(punch3);

  Punch punchCahier(10, "Si vous saviez faire un cahier des charges vous nous entendriez mois gueuler", "Normal", "Travail");
  CVC.learnPunch(punchCahier);


  //ENNEMIS


  //Alligot
  Personnage MA("Mr Alligot", "Travail", "Famille", "Ennemi");

  PunchLourd punchPLD1(20, "Attention tu vas t'envoler à force de brasser de l'air comme ça !", "Normal", "Physique", 10);
  MA.learnPunch(punchPLD1);

  PunchLourd punchPLD2(20, "Ton travail est aussi dégueulasse que ta gueule.", "Normal", "Physique", 10);
  MA.learnPunch(punchPLD2);

  PunchLeger punchPLG4(20, "Et ton ripomatic il en est où ?", "Normal", "Travail", 10);
  MA.learnPunch(punchPLG4);

  Punch punchP3(20, "T'as remarqué que personne n'aime ton travail ?", "Normal", "Travail");
  MA.learnPunch(punchP3);


  //Land Hero
  Personnage MLH("Mr Land Hero", "Famille", "Physique", "Ennemi");

  PunchLourd punchPLD0(20, "T'es comme un de ces salopards d'illusionnistes, t'as aucune logique.", "Normal", "Travail", 10);
  MLH.learnPunch(punchPLD0);

  PunchLeger punchPLG1(20, "Alors comme ça on rush la semaine pour avoir le week end de libre ?", "Normal", "Travail", 10);
  MLH.learnPunch(punchPLG1);

  Punch punchP4(20, "Quitte à passer autant de temps sur ton taff, tu pourrais rendre un truc acceptable ?", "Normal", "Travail");
  MLH.learnPunch(punchP4);

  Punch punchP5(20, "C'est quoi ce chapeau ? Tu t'es pris pour Lucky Luke ?", "Normal", "Physique");
  MLH.learnPunch(punchP5);


  //Mifroid
  Personnage MM("Mr Mifroid", "Physique", "Travail", "Ennemi");

  PunchLeger punchPLG0(20, "Alors comme ça on essaie d'avoir la moyenne ? Tu sais qu'il faut déjà que tu rende un travail pour ça ?", "Normal", "Travail", 10);
  MM.learnPunch(punchPLG0);

  PunchLeger punchPLG2(20, "Tout le monde sait que vous êtes des segpa.", "Normal", "Travail", 10);
  MM.learnPunch(punchPLG2);

  Punch punchP0(20, "Grâce à vous je suis devenu devin, l'etpa a ouvert cette année mais je sais déjà qu'elle va fermer l'an prochain.", "Normal", "Travail");
  MM.learnPunch(punchP0);

  Punch punchP1(20, "Joyeux demi-anniversaire ! Aujourd'hui on fête ton 6ème mois d'échec scolaire.", "Normal", "Travail");
  MM.learnPunch(punchP1);

  //Remplissage de l'assemblée
  Public familia("Familia");

  /*

  //PUNCHS Rab
  //Punch éléve -> Prof

  //Punch Lourd PunchLourd(int d, string n, string e, string t, int dp);
  
  PunchLourd punchLD4(10,"Tue pues.", "Normal", "Famille", 10);
  PunchLourd punchLD5(10,"T'es ideux.", "Normal", "Famille", 10);
  PunchLourd punchLD6(10,"T'es un laidron mais t'es bien bonne.", "Normal", "Famille", 10);

  //Punch leger PunchLeger(int d, string n, string e, string t, int dp);
  
  //Punch Punch(int deg, string nom, string effet, string typ);
  
  Punch punch5(10, "Et si vous appreniez à rédiger un cahier des charges ?",  "Normal",  "Travail");
  
  Punch punch8(10,  "Vous avez pensé à perdre du poids ?",  "Normal",  "Physique");
  
  //Punch Prof -> Elève

  //Punch Lourd PunchLourd(int d, string n, string e, string t, int dp);

  PunchLourd punchPLD3(20, "On a les même yeux avec tes parents ? Ouai ? Bah pourqoui ils t'ont gardé quand t'es sorti ?", "Normal", "Physique", 10);
  PunchLourd punchPLD4(20, "Ta gueule ! J'te prends j'te r'tourne !!", "Normal", "Physique", 10);
  PunchLourd punchPLD5(20, "Le plus débile des enfants est toujours le préféré des parents, je suis sûr que les tiens t'adore.", "Normal", "Famille", 10);
  PunchLourd punchPLD6(20, "**pff** jes suis ton père **pff** j'ai b**ser ta mère **pff**.", "Normal", "Famille", 10);

  //Punch leger PunchLeger(int d, string n, string e, string t, int dp);

  PunchLeger punchPLG3(20, "Tu sais pas utiliser un cutter ?", "Normal", "Travail", 10);
  
  PunchLeger punchPLG5(20, "Même un clavier à moins de boutons", "Normal", "Physique", 10);
  PunchLeger punchPLG6(20, "Oh une tête de gland", "Normal", "Physique", 10);
  PunchLeger punchPLG7(20, "Lève les bras je veux vérifier un truc, ah ouai, tu pues...", "Normal", "Physique", 10);

  //Punch Punch(int deg, string nom, string effet, string typ);

  Punch punchP2(20, "T'es mauvais .. tu sais pas programmer.", "Normal", "Travail");
  
  Punch punchP6(20, "Fais gaffe avec autant d'acné on va te prendre pour un pestiféré !", "Normal", "Physique");
  Punch punchP7(20, "Ta famille doit avoir honte", "Normal", "Famille");
  
  //Autres
  Punch punchMamie(10, "Ta grand mère !", "Normal", "Famille");
  Punch punchOrga(10, "Et l'organisation ça vous dirais de vous pencher dessus ?", "Normal", "Travail");
  Punch punchFumette(10, "Mais vous fumez monsieur", "Normal", "Travail");
  Punch punchCafe(10, "Alors on peut pas bosser si on a pas bu son cafe ?", "Normal", "Travail");
  Punch punchCutter(10, "Vous savez pas utiliser un cutter ?? Hein ??", "Normal", "Physique");

  */

  //Ajout dans le tableau à faire un dernier
  //Eleves
  vector<Personnage*> team;
  team.push_back(&Mk);
  team.push_back(&LW);
  team.push_back(&BB);
  team.push_back(&HH);
  team.push_back(&OS);
  team.push_back(&CVC);

  //prof
  vector<Personnage*> adversaires;
  adversaires.push_back(&MA);
  adversaires.push_back(&MLH);
  adversaires.push_back(&MM);

  // cout << Mk;

  //Variables pour la boucle de jeu
  int round = 1;
  int combat = 1;
  string oldPunch;
  string oldPunchEnnemi;
  int enemyActif = 0;
  int choixPerso = -1;

// ------- ****  on tente l'intro textuelle 

  cout<<""<<endl<<endl<<endl<<endl;

  cout<<"             -*-*-*- DEBUT DE L'AVENTURE TEXTUELLE DE LA TEAM CROQUETTE -*-*-*- "<<endl<<endl<<endl<<endl<<endl;


  cout<<"   A l'approche de la fin du projet de semestre 2, les étudiants de l'ETPA Montpellier commencent à être atteint de folie,   voyant  l'organisation    de l'établissement s'écroule sur   elle-même. "<<endl<<endl;

  cout<<"   Une rébellion contre la ligue maléfique des professeurs éclate pour la liberté des droits des étudiants dans l'espoir d'un avenir meilleur, alors qu'un destin de chômeurs les attend. "<<endl<<endl;

  cout<<" Les élèves se liguent contre les profs et s'affrontent sur un ring lors de battles de clash"<<endl<<endl;


  cout<<"  << OBJECTIF : Le premier à avoir rempli la jauge de honte de l'adversaire à 100 points gagne  le match. >> "<<endl<<endl;


  cout<<"  Battez tous les profs avec votre équipe d'élèves avant que ceux-ci n'aient trop honte pour continuer la rébellion. Non mécontent d'avoir de l'animation au sein de l'école, un public assiste aux matchs.  Attirez vous les faveurs du public en montant  sa jauge vous permettra également de vaincre un adversaire qui, poussé par la foule, sera contraint de quitter le ring. Attention, si le public peut être un bon soutient, il peut également se retourner contre vous si vous faites des punchlines trop lourdes ! "<<endl<<endl<<endl<<endl;

  cout<<"                              -*-*-*- A VOUS DE JOUER -*-*-*- "<<endl<<endl<<endl<<endl<<endl;

  cout << "Entrez 1 pour continuer" << endl;
  cin >> skip;
  system("clear");

  //CHOIX PERSONNAGE
	while(choixPerso < 0 || choixPerso > 5) 
  {
		for(int i = 0; i<team.size(); i++)
    {
      cout<<"Joueur n°"<<i<<endl;
      cout<< team[i]->getName()<<endl<<endl;
    }

    cout<<""<<endl;

		cout << " Entrez le numéro de votre combattant  " << endl;
		cin >> choixPerso;

    while(choixPerso < 0 || choixPerso > 5)
    {
      cout << "Veuillez entrer un chiffre entre 0 et 5 pour selectionner le personnage"<<endl;
      cin >> choixPerso;
    }

    cout << choixPerso << endl;
  }

  Ring ring("ring", *team[choixPerso], *adversaires[enemyActif]);

  //BOUCLE DE JEU
  while(enemyActif != 3)
  {
    while(ring.actif("ennemi")->getHonte() <= 100 || ring.actif("joueur")->getHonte() <= 100) 
    {
      int choice = 0;

      //Texte
      cout<<endl;
      cout<<"-------Combat : "<< combat << "-------"<<endl;
      cout<<"-------Rounds : "<< round << "-------"<<endl<<endl;
      cout << ring.actif("joueur")->getName()
        << " : "
        << ring.actif("joueur")->getHonte()
        << " VS "
        << adversaires[enemyActif]->getName()
        << " : "
        << adversaires[enemyActif]->getHonte()
        << endl;
      cout<<"Interêt du public : "<<familia.getInterest()<<endl;
      cout<<endl;

      //Rage du Public
      if(familia.getInterest() >= 100)//joueur perd
      {
        cout<<"Sam monte sur le ring et éjecte "<<ring.actif("joueur")->getName()<<endl;
        ring.actif("joueur")->setHonte(100);
        break;
      }
      else if(familia.getInterest() <= 0)//ennemi perd
      {
        cout<<"Sam monte sur le ring et éjecte "<<ring.actif("ennemi")->getName()<<endl;
        enemyActif++;
        break;
      }

      //MORT DES PERSO
      if(ring.actif("joueur")->getHonte() >= 100)
      {
        team.erase(team.begin() + choixPerso);
        
        cout<<ring.actif("joueur")->getName()<<" est éjecté du ring !"<<endl;
        cout<<endl;

        int change = -1;
        for(int i = 0; i< team.size(); i++)
        {
          cout<<"Joueur n°"<<i<<endl;
          cout<<team[i]->getName()<<endl<<endl;
        }
        cout << "- Qui entre sur le ring ?(numéro)" << endl;
        cin >> change;

        choixPerso = change;
        ring.changement(*team[change], "joueur");
        
        cout << ring.actif("joueur")->getName()<<" entre sur scène"<<endl<<endl;
        cout << ring.actif("joueur")->getName()
          << " : "
          << ring.actif("joueur")->getHonte()
          << " VS "
          << adversaires[enemyActif]->getName()
          << " : "
          << adversaires[enemyActif]->getHonte()
        << endl<<endl;
      }

      //CHOIX ACTION DU TOUR
      cout << "- Que faire ?(numéro)" << endl 
        << "1 -> Attaquer" << endl
        << "2 -> Swap" << endl
        << "3 -> Abandonner" << endl
        << endl;
      cin >> choice;

      //Attaque joueur
      if (choice == 1)
      {
        int attaqueChoice = -1;
        cout << "- Quelle punch choisissez vous ? " << endl << endl;
        for(int i = 0; i < 4; i++)
        {
          if(ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), i)->getName() == oldPunch)
          {
            cout << i << " : " << ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), i)->getName() << "Punch en cooldown" << endl << endl;
          }
          else
          {
            cout << i << " : "
              // << ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), i)->getName()
              // << ", Degâts : "
              // << ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), i)->getDegats()
              // << ", Type : "
              // << ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), i)->getType()
              /*
              << ", E : "
              << ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), i)->getEffect()
              */
              // << endl
              ;
            cout << *ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), i);
          }
        }
        cout << endl;
        cin >> attaqueChoice;
        
        if(ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), attaqueChoice)->getName() == oldPunch)
        {
          cout << "Aie la répétition ne plait pas au public ..."<<endl;

          familia.setInterest(familia.getInterest() + 10);
          oldPunch = "";
        }
        else
        {
          ring.actif("joueur")->punchEnemy(*ring.actif("joueur"), *ring.actif("ennemi"),*ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), attaqueChoice), familia);

          oldPunch = ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), attaqueChoice)->getName();
        }
        
      }
      //Swap
      else if (choice == 2)
      {
        int change = -1;
        //Affiche la team
        for(int i = 0; i< team.size(); i++)
        {
          cout<<"Joueur n°"<<i<<endl;
          cout<<team[i]->getName()<<endl;
        }
        cout<<endl;

        cout << "Qui sera le prochain challenger à monter sur le ring ?(numéro)" << endl;
        cin >> change;

        while(change < 0 || change > team.size())
        {
          cout << "Veuillez entrer un chiffre entre 0 et 5 pour selectionner le personnage"<<endl;
          cin >> change;
        }

        choixPerso = change;
        ring.changement(*team[change], "joueur");
        
        cout << *team[change] << endl;
      }
      //Anbandon
      else if(choice == 3)
      {
        cout << ring.actif("joueur")->getName() << " déclare lachement forfait." << endl << endl;
        enemyActif = 3;
        break;
      }
      //Inaction
      else
      {
        cout<<ring.actif("joueur")->getName()<< " gobe les mouches."<<endl;
      }

      //Mort Ennemi
      if(ring.actif("ennemi")->getHonte() >= 100)
      {
        cout<<endl;
        cout << ring.actif("ennemi")->getName() << " est vaincu !!!"<< endl;

        enemyActif++;
        ring.changement(*adversaires[enemyActif], "ennemi");
        cout<<endl;
        cout<< "Un nouvel ennemi monte sur le ring !!"<<endl;
        cout << ring.actif("ennemi")->getName() << " est maintenant dans la place!! "<< endl;

        familia.setInterest(50);

        combat++;
        round = 1;
        break;
      }

      //TOUR DE L'ENNEMI
      int num = rand() % 3 + 1;

      cout << endl;
      cout<<ring.actif("ennemi")->getName()<<" passe à l'offensive"<<endl;

      if(ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), num)->getName() == oldPunchEnnemi)
        {
          cout << "Aie la répétition ne plait pas au public ..."<<endl;

          familia.setInterest(familia.getInterest() - 10);
          oldPunchEnnemi = "";
        }
        else
        {
          ring.actif("ennemi")->punchEnemy(*ring.actif("ennemi"), *ring.actif("joueur"), *ring.actif("ennemi")->getElemPunchs(ring.actif("ennemi")->getPunchs(), num), familia);

          cout << endl;

          oldPunchEnnemi = ring.actif("joueur")->getElemPunchs(ring.actif("joueur")->getPunchs(), num)->getName();
        }

      round++;

      cout << "Entrez 1 pour continuer" << endl;
      cin >> skip;
      system("clear");
    }
    cout<<endl;
  }

  //Victoire et défaite
  if(MM.getHonte() >=100)
  {
    cout<<"Vous avez vaincu la ligue maléfique !!!"
    <<endl
    <<"Le monde est désormais sûr !"
    <<endl<<endl;
  }
  else
  {
    cout<<"La ligue maléfique à vaincu votre team."
    <<endl
    <<"Le monde est désormais soumis à ces êtres diaboliques !"
    <<endl<<endl;
  }

  return 0;
}