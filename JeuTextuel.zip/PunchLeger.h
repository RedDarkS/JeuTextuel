#ifndef PUNCHLEGER_H
#define PUNCHLEGER_H

#include <iostream>
#include <string>
#include "Punch.h"

using namespace std;

class PunchLeger : public Punch
{
  private:
    int degatLeger = 10;

  public:

    //constructeurs
    PunchLeger();
    PunchLeger(int d, string n, string e, string t, int dp);
    // ~PunchLeger();

    //Getter
    int getDegatLeger() const;

    //Setter
    void setDegatLeger(int dp);

    //Méthode
    void attackPublic(Personnage &lanceur, Personnage &cible, Public &p);
    virtual void effect(Personnage &lanceur, Personnage &cible, Public &p);
    friend ostream& operator<<(ostream& os,PunchLeger const &p);
};

#endif // PUNCHLEGER_H