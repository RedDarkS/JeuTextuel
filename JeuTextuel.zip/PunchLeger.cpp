#include "PunchLeger.h"

//CONSTRUCTEURS
PunchLeger::PunchLeger() : Punch()
{
  setDegats(getDegats()/2);
}
PunchLeger::PunchLeger(int d, string n, string e, string t, int dp) : Punch(d, n, e, t)
{
  degatLeger = dp;
  setDegats(getDegats()/2);
}
// PunchLeger::~PunchLeger()
// {
//   cout<<"Punch leger oublié"<<endl;
// }

//GETTERS
int PunchLeger::getDegatLeger() const
{
  return degatLeger;
}

//SETTERS
void PunchLeger::setDegatLeger(int dp)
{
  degatLeger = dp;
}

//METHODES
void PunchLeger::attackPublic(Personnage &lanceur, Personnage &cible, Public &p)
{
  if(cible.getType() == "Joueur")
  {
    cout << "Le public gagne " 
      << getDegatLeger() 
      << " d'interet pour "
      << lanceur.getName()//l'ennemi
      << endl;
    p.setInterest(p.getInterest() + getDegatLeger());
  }
  else
  {
    cout << "Le public gagne " 
      << getDegatLeger() 
      << " d'interet pour "
      << lanceur.getName()//le joueur
      << endl;
    p.setInterest(p.getInterest() - getDegatLeger());
  }
  
}
void PunchLeger::effect(Personnage &lanceur, Personnage &cible, Public &p)
{
  // cout<<"Punch leger"<<endl;
  if(cible.getFaiblesse() == getType())
  {
    cout<<"Ouch ça fait très mal !"<<endl;
    cible.setHonte(cible.getHonte() + (getDegats()*2) );
  }
  else if(cible.getResistance() == getType())
  {
    cout<<"ça ne semble pas avoir fait mal."<<endl;
    cible.setHonte(cible.getHonte() + (getDegats()/2) );
  }
  else
  {
    cout<<"Ouch !"<<endl;
    cible.setHonte(cible.getHonte() + getDegats());
  }
  attackPublic(lanceur, cible, p);
}
ostream& operator<<(ostream& os,PunchLeger const &p)
{
  os<<"----"<<p.getName()<<"----"<<endl;
  os<<"----Punch léger----"<<endl;
  os<<"Type = "<<p.getType()<<endl;
  os<<"Degats = "<<p.getDegats()<<endl;
  os<<"Degats sur le public = "<<p.getDegatLeger()<<endl<<endl;
  // os<<"Effets = "<<p.getEffect()<<endl<<endl;
  return os;
}