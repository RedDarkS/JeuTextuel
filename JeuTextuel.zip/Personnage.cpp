#include "Personnage.h"

//CONSTRUCTEURS / DESTRUCTEURS
Personnage::Personnage()
{
  name = "defaut";
  faiblesse = "null";
  resistance = "null";
  type = "null";
}
Personnage::Personnage(string n, string f, string r, string typ)
{
  name = n;
  faiblesse = f;
  resistance = r;
  type = typ;
}
// Personnage::~Personnage()
// {
//   cout<<getName()<<" est mort de honte !"<<endl;
// }

//GETTERS
string Personnage::getName()const
{
  return name;
}
int Personnage::getHonte()const
{
  return honte;
}
string Personnage::getFaiblesse() const
{
  return faiblesse;
}
string Personnage::getResistance() const
{
  return resistance;
}
vector<Punch*> Personnage::getPunchs() const
{
  return punchs;
}
Punch* Personnage::getElemPunchs(vector<Punch*> p, int index) const
{
  return p[index];
}
string Personnage::getType() const
{
  return type;
}

//SETTERS
void Personnage::setName(string n)
{
  name = n;
}
void Personnage::setHonte(int h)
{
  honte = h;
}
void Personnage::setFaiblesse(string f)
{
  faiblesse = f;
}
void Personnage::setResistance(string r)
{
  resistance = r;
}
void Personnage::setPunchs(vector<Punch*> p)
{
  punchs = p;
}
void Personnage::setType(string t)
{
  type = t;
}

//METHODES
void Personnage::learnPunch(Punch &p)
{
  if(punchs.size() < 4)
  {
    punchs.push_back(&p);
  }
  else
  {
    cout<<"trop de punch connu"<<endl;
  }
}
void Personnage::punchEnemy(Personnage &lanceur, Personnage &cible, Punch &p, Public &pb)
{
  cout<<getName()<<" : "<<cible.getName()<< " " <<p.getName()<<endl;
  p.effect(lanceur, cible, pb);
}
ostream& operator<<(ostream& os,Personnage const &p)
{
  os<<"----"<<p.getName()<<"----"<<endl;
  os<<"Niveau de honte = "<<p.getHonte()<<endl<<endl;
  os<<"Faible à "<<p.getFaiblesse()<<endl<<endl;
  os<<"Resistant à "<<p.getResistance()<<endl<<endl;
  os<<"----"<<" Punchs connus "<<"----"<<endl;

  for(int i = 0; i < p.getPunchs().size(); i++)
  {
    os<<p.getElemPunchs(p.getPunchs(), i)->getName()<<endl<<endl;
  }
  return os;
}