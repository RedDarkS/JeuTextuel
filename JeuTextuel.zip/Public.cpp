#include "Public.h"

//Constructeurs
Public::Public(string n)
{
  name = n;
}
// Public::~Public()
// {
//   cout<<"Le public a quitté la salle"<<endl;
// }

//Getters
int Public::getInterest()const
{
  return interest;
}

//Setters
void Public::setInterest(int i)
{
  interest = i;
}

//METHODES
ostream& operator<<(ostream& os,Public const &p)
{
  os<<"----"<<"Le public"<<"----"<<endl;
  os<<"Niveau d'interet' = "<<p.getInterest()<<endl<<endl;
  return os;
}